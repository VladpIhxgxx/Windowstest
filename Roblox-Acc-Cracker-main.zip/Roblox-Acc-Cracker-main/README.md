# Roblox-Acc-Cracker
This is for ppl who wanna pg og accounts I got my hands on hhs21, Most creds go to h0nda


# Requirements:
Python 3.6 or later
requests module - installed via command: pip install requests

# Usage:
Place combos in combos.txt
Place proxies in proxies.txt
Launch get_token.py and follow instructions, make sure ur signed into ur microsoft acc.
Launch start.bat
